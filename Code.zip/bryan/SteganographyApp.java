package com.steganography;

import java.util.Scanner;

public class SteganographyApp {
    public static void main(String[] args) {
        Steganography stegano = new Steganography();
        String message;
        String imagePath = "D:\\Binus\\Binus4\\Research In Metodology Computer Science\\Research\\DataSet\\14.png";
        String outputImagePath = "D:\\Binus\\Binus4\\Research In Metodology Computer Science\\Research\\DataSet\\Result2\\Lena.png"; // chg

        int cho;
        String secretKeyTime, secretKeyMessage, cipherSecretKeyMessage;
        Scanner input = new Scanner(System.in);
        AES aesMachineTime, aesMachineMessage;
        do{
            menu();
            cho = input.nextInt(); input.nextLine();
            switch (cho) {
                case 1 -> {
                    System.out.print("Input the User Key : ");
                    secretKeyTime = input.nextLine();
                    System.out.print("Input the message : ");
                    message = input.nextLine();
//                    secretKeyMessage = Time.getTime();

                    long startTime = System.currentTimeMillis();
                    secretKeyMessage = "14:25";
                    aesMachineTime = new AES(secretKeyTime);                                // AES with inputted key
                    cipherSecretKeyMessage = aesMachineTime.encrypt(secretKeyMessage);      // encrypt time -> KEY
                    aesMachineMessage = new AES(cipherSecretKeyMessage);                    // AES with KEY
                    String cipherTextMessage = aesMachineMessage.encrypt(message) + "\n";   // encrypt message -> Cipher Text
                    stegano.insert(cipherTextMessage, imagePath, outputImagePath);
                    long stopTime = System.currentTimeMillis();
                    System.out.println("Insert Time = "+(stopTime-startTime)+"milliseconds");
                }
                case 2 -> {
                    System.out.print("Input the User Key : ");
                    secretKeyTime = input.nextLine();
//                    secretKeyMessage = Time.getTime();

                    long startTime = System.currentTimeMillis();
                    secretKeyMessage = "14:25";
                    aesMachineTime = new AES(secretKeyTime);
                    cipherSecretKeyMessage = aesMachineTime.encrypt(secretKeyMessage);
                    aesMachineMessage = new AES(cipherSecretKeyMessage);
                    String cipherTextMessage2 = stegano.deInsert(outputImagePath);
                    String secretMessage = aesMachineMessage.decrypt(cipherTextMessage2);
                    long stopTime = System.currentTimeMillis();
                    System.out.println("Extract Time = "+(stopTime-startTime)+"milliseconds");

                    System.out.println("Extract Message = "+secretMessage);
                }
            }
        }while (cho!=3);
    }
    public static void menu(){
        System.out.println("1. Generate SteganoGraphy Image");
        System.out.println("2. Read Steganography Image");
        System.out.print("Choose:");
    }
}
