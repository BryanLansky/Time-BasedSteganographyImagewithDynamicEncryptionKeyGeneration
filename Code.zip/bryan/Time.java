package com.steganography;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Time {
    public static String getTime() {
        SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm");
        String time = localDateFormat.format(new Date());
        return time;
    }

    public static void main(String[] args) {
        System.out.print(getTime());
    }
}
