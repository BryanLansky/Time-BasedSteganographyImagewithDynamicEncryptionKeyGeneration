package com.steganography;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Steganography stegano = new Steganography();
        String message;
        String imagePath = "D:\\Binus\\Binus4\\Research In Metodology Computer Science\\" +
                "Research\\DataSet\\12.png";
        String outputImagePath = "D:\\Binus\\Binus4\\Research In Metodology Computer Science\\" +
                "Research\\DataSet\\ResultStegano\\12.png";

        String secretKeyTime, secretKeyMessage, cipherSecretKeyMessage;
//        Scanner input = new Scanner(System.in);
        AES aesMachineTime, aesMachineMessage;

        secretKeyTime = "tailung";
        message = "You cannot stop the unstoppable";
        secretKeyMessage = "14:25";
        aesMachineTime = new AES(secretKeyTime);
        cipherSecretKeyMessage = aesMachineTime.encrypt(secretKeyMessage);
        aesMachineMessage = new AES(cipherSecretKeyMessage);
        String cipherTextMessage = aesMachineMessage.encrypt(message) + "\n";
        stegano.insert(cipherTextMessage, imagePath, outputImagePath);
        System.out.println("KEY MESSAGE = "+ cipherSecretKeyMessage);

        System.out.println("Cipher = "+cipherTextMessage);

        secretKeyTime = "tailung";
        secretKeyMessage = "14:25";
        aesMachineTime = new AES(secretKeyTime);
        cipherSecretKeyMessage = aesMachineTime.encrypt(secretKeyMessage);
        System.out.println("KEY MESSAGE = "+ cipherSecretKeyMessage);
        aesMachineMessage = new AES(cipherSecretKeyMessage);
        String cipherTextMessage2 = stegano.deInsert(outputImagePath);
        String secretMessage = aesMachineMessage.decrypt(cipherTextMessage2);

        System.out.println("Extract = " + secretMessage);
    }
}
